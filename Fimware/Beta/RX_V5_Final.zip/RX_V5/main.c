#include "msp430.h"

//USCI_A0
#define UART_TX_READY       (UCA0IFG & UCTXIFG)
#define UART_RX_READY       (UCA0IFG & UCRXIFG)
#define UART_TX_DONE        (UCA0IFG & UCTXCPTIFG)
#define UART_RESET_TX_DONE  (UCA0IFG &= ~UCTXCPTIFG)
int i, d;
int main(void)
{
  WDTCTL = WDTPW | WDTHOLD;                 // Stop Watchdog

  // Configure GPIO
  P3OUT &= ~(BIT0|BIT1);                       // Clear P2.0 output latch
   P3DIR |= BIT0|BIT1;                        //LED & Module
   P3OUT |= BIT0|BIT1;

   P4DIR |= (BIT0);                                 //5V enable
   P4OUT |= BIT0;

   P1OUT &= ~(BIT4 | BIT5 | BIT1 | BIT2);
   P1DIR |= BIT4 | BIT5 | BIT1 | BIT2;             //Bit 4 RFSD, Bit 5 Mode0, Bit 1 Buzz, Bit2 Sol
   P1OUT |= BIT5;                                   // Transmit Mode RF
   P1OUT |= BIT4;                                   // Switch on RF

   P2SEL1 |= BIT0 | BIT1;                    // USCI_A0 UART operation
   P2SEL0 &= ~(BIT0 | BIT1);


   // Disable the GPIO power-on default high-impedance mode to activate
   // previously configured port settings
   PM5CTL0 &= ~LOCKLPM5;

   // Startup clock system with max DCO setting ~8MHz
   CSCTL0_H = CSKEY >> 8;                    // Unlock clock registers
   CSCTL1 = DCOFSEL_3 | DCORSEL;             // Set DCO to 8MHz
   CSCTL2 = SELA__VLOCLK | SELS__DCOCLK | SELM__DCOCLK;
   CSCTL3 = DIVA__1 | DIVS__1 | DIVM__1;     // Set all dividers
   CSCTL0_H = 0;                             // Lock CS registers

   // Configure USCI_A0 for UART mode
   UCA0CTLW0 = UCSWRST;                      // Put eUSCI in reset
   UCA0CTLW0 |= UCSSEL__SMCLK;               // CLK = SMCLK
   // Baud Rate calculation
   // 8000000/(16*9600) = 52.083
   // Fractional portion = 0.083
   // User's Guide Table 21-4: UCBRSx = 0x04
   // UCBRFx = int ( (52.083-52)*16) = 1
   UCA0BR0 = 52;                             // 8000000/16/9600
   UCA0BR1 = 0x00;
   UCA0MCTLW |= UCOS16 | UCBRF_1;
   UCA0CTLW0 &= ~UCSWRST;                    // Initialize eUSCI
   UCA0IE |= UCRXIE;                         // Enable USCI_A0 RX interrupt


   __delay_cycles(10000000);
//  UCA0TXBUF = 'B';
   P3OUT ^= BIT0|BIT1;
   __bis_SR_register(LPM3_bits | GIE);       // Enter LPM3, interrupts enabled
   __no_operation();                         // For debugger
 }

void delay_ms(unsigned int ms )
{
    unsigned int i;
    for (i = 0; i<= ms; i++)
       __delay_cycles(500); //Built-in function that suspends the execution for 500 cicles
}

void beep()
{

    for (i=0;i<500;i++)
    {
        P1OUT |= BIT1;     //Set P1.1 Buzzer
        __delay_cycles(5000); //Square wave
        P1OUT &= ~BIT1;    // reset Buzzer...
        __delay_cycles(5000);
    }
    delay_ms(d);
}
 #if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
 #pragma vector=USCI_A0_VECTOR
 __interrupt void USCI_A0_ISR(void)
 #elif defined(__GNUC__)
 void __attribute__ ((interrupt(USCI_A0_VECTOR))) USCI_A0_ISR (void)
 #else
 #error Compiler not supported!
 #endif
 {
   switch(__even_in_range(UCA0IV, USCI_UART_UCTXCPTIFG))
   {
     case USCI_NONE: break;
     case USCI_UART_UCRXIFG:
       if (UCA0RXBUF == 'U') // 'U' received?  OVERFLOW BYTE
        {
           P3OUT |= (BIT0|BIT1);
           P1OUT |= (BIT2);        // Sol ON
           d= 100;                 // Tone Delay
           beep();                 // Buzz
        }
       else if (UCA0RXBUF == 'O') // 'O' received?   ROLL BACK OVERFLOW
        {
         P3OUT &= ~(BIT0|BIT1);        // LED off
         P1OUT &= ~(BIT2|BIT1);        // Sol & buzzer off
        }
       else if (UCA0RXBUF == 'A') // 'A' received?    BASE CALB/CALB MODE
       {
         P3OUT |= (BIT1);      // Red LED on
         d =3000;               // Tone delay
         beep();                // Buzz
         P3OUT ^= (BIT1);       // LED off
         }
       else if (UCA0RXBUF == 'B') // 'B' received?  FLUSH CALB
         {
           P3OUT |= (BIT0);     // Green LED on
           d = 500;             // Tone Delay
           beep();              // Buzz
           P3OUT ^= (BIT0);     //LED off
           }
       else if (UCA0RXBUF == 'C') // 'C' received? CALB DONE
          {
            P3OUT |= (BIT0|BIT1);   //Both LED On
            d= 4000;                // Tone delay
            delay_ms(d);            // No op to diff end tone? You know hat i mean probably not :D
            beep();
            beep();
            P3OUT ^= (BIT0|BIT1);       //LED off
           }
       __no_operation();
       break;
     case USCI_UART_UCTXIFG: break;
     case USCI_UART_UCSTTIFG: break;
     case USCI_UART_UCTXCPTIFG: break;
   }
 }
