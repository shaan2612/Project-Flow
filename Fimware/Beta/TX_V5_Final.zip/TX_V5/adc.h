/*
 * adc.h
 *
 *  Created on: Mar 5, 2018
 *      Author: farshid
 */

#ifndef ADC_H_
#define ADC_H_

void adc_init(void);
void adc_start(void);
void adc_stop(void);

#endif /* ADC_H_ */
