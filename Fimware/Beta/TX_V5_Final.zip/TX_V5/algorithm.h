/*
 * algorithm.h
 *
 *  Created on: Mar 5, 2018
 *      Author: farshid
 */

#ifndef ALGORITHM_H_
#define ALGORITHM_H_


void calibrationProcess(void);
void montor(void);
void buffer_init(void);
void calibration(void);
void monitor(void);

#endif /* ALGORITHM_H_ */
